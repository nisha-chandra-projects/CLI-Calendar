# CLI-Calendar

PrintACalendar.java - Program to create a Month Calendar in Command Line with user-input month and year

```java PrintACalendar <month> <year>```


